# Connect6-Algorithm
