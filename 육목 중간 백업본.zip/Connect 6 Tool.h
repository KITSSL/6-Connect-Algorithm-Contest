#ifndef _CONNECT_6_TOOL_H_
#define _CONNECT_6_TOOL_H_

#include <cinttypes>
#include <memory.h>
#include <stdlib.h>

#ifndef SAFE_DELETE
	#define SAFE_DELETE(pointer) { if (pointer != NULL) delete pointer; pointer = NULL; }
#endif

static const int32_t BOARD_SIZE = 19;
static const int32_t MAX_TURN   = BOARD_SIZE * BOARD_SIZE;

enum class STATUS : uint8_t
{
	NONE     = 99,
	EMPTY    = 0,
	PLAYER1  = 1,
	PLAYER2  = 2,
	BLOCKING = 3
};

enum class TURN : uint8_t
{
	NONE,
	PLAYER1	 = 1,
	PLAYER2	 = 2
};

enum class GAME_RESULT : uint8_t
{
	NONE,
	PLAYER1_WIN,
	PLAYER2_WIN,
	DRAW
};

class Connect6
{
private:
	Connect6() { }
	
public:
	~Connect6() { SAFE_DELETE(Connect6::instance); }

public:
	static Connect6* Initialize();
	static Connect6* GetInstance();

public:
	void Display();
	TURN Start(const uint32_t blockingNumber = 2);
	
public:
	int(*GetBoard(int copy_board[19][19]))[19];
	auto GetCurrentTurn() { return m_currentTurn; }
	auto GetTurnCount() { return m_turnCount - m_blockingNumber; }
	STATUS IsFree(uint32_t iy, uint32_t ix);
	GAME_RESULT Placement(int x[], int y[], int cnt);									//�� �� ���� �����Լ�
	void OnePlacement(uint32_t iy, uint32_t ix);						//�Ѱ��� �� ���� �Լ�
	void TurnChange();
	GAME_RESULT Judgement(uint32_t ix, uint32_t iy);
	GAME_RESULT Judgement();
	//GAME_RESULT Judgement(uint32_t iy, uint32_t ix);					//���� �� ���� �Լ�
	uint32_t CheckIndex(uint32_t iy, uint32_t ix);
	int showboard(int x, int y);
private:
	static Connect6* instance;

private:
	STATUS  m_board[BOARD_SIZE][BOARD_SIZE];
	int32_t m_blockingNumber;
	TURN    m_currentTurn;
	int32_t m_turnCount;
	GAME_RESULT m_result;
};

#endif