#include "Connect 6 Tool.h"

#include <iostream>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>

Connect6* Connect6::instance;

Connect6* Connect6::Initialize()
{
	assert(Connect6::instance == NULL);

	Connect6::instance = new Connect6();

	return Connect6::instance;
}

Connect6* Connect6::GetInstance()
{
	assert(Connect6::instance != NULL);

	return Connect6::instance;
}

void Connect6::Display()
{
	system("cls");

	std::string colIndex = "    A B C D E F G H I J K L M N O P Q R S\n";
	std::string divLine  = "  +---------------------------------------+\n";

	fwrite(colIndex.data(), colIndex.size(), 1, stdout);
	fwrite(divLine.data(), divLine.size(), 1, stdout);

	for (int iy = 0; iy < BOARD_SIZE; ++iy)
	{
		fwrite(std::to_string(iy).data(), 2, 1, stdout);
		fwrite(std::string("  ").data(), 2, 1, stdout);

		for (int ix = 0; ix < BOARD_SIZE; ++ix)
			switch (m_board[iy][ix]) {
			case STATUS::NONE:
				fwrite(" ", 2, 1, stdout);
				break;
			case STATUS::PLAYER1:
				fwrite("B", 2, 1, stdout);
				break;
			case STATUS::PLAYER2:
				fwrite("W", 2, 1, stdout);
				break;
			case STATUS::BLOCKING:
				fwrite("H", 2, 1, stdout);
				break;
			default:
				fwrite(" ", 2, 1, stdout);
				break;
			}
		//fwrite(std::string(static_cast<char>((int)m_board[iy][ix]+65) + std::string(" ")).data(), 2, 1, stdout);

		fwrite("\n", 1, 1, stdout);
	}

	fwrite(divLine.data(), divLine.size(), 1, stdout);
	fwrite("\n", 1, 1, stdout);
}

TURN Connect6::Start(const uint32_t blockingNumber)
{
	assert(Connect6::instance != NULL);
	assert(blockingNumber >= 0);

	std::random_device              randomDevice;
	std::mt19937                    randomEngine(randomDevice());
	std::uniform_int_distribution<> turnDistribution(0, 1);
	std::uniform_int_distribution<> blockingDistribution(0, BOARD_SIZE - 1);

	memset(m_board, static_cast<int>(STATUS::EMPTY), sizeof(m_board));

	//for (uint32_t index = 0; index < blockingNumber; ++index)
	//	m_board[blockingDistribution(randomEngine)][blockingDistribution(randomEngine)] = STATUS::BLOCKING;

	m_blockingNumber = blockingNumber;
	m_currentTurn = (turnDistribution(randomEngine) == 0) ? (TURN::PLAYER1) : (TURN::PLAYER2);
	m_turnCount      = blockingNumber;
	
	for (uint32_t index = 0; index < blockingNumber; ++index) {
		int rand_x = blockingDistribution(randomEngine);
		int rand_y = blockingDistribution(randomEngine);
		while (rand_x == 10 && rand_y == 10) {
			rand_x = blockingDistribution(randomEngine);
			rand_y = blockingDistribution(randomEngine);
		}
		m_board[rand_x][rand_y] = STATUS::BLOCKING;
	}

	return m_currentTurn;
}

STATUS Connect6::IsFree(uint32_t iy, uint32_t ix) {
	return m_board[iy][ix];
}

GAME_RESULT Connect6::Placement(int x[],int y[],int cnt){
	GAME_RESULT result;

	for (uint32_t index = 0; index < cnt; index++) {
		if (IsFree(x[index], y[index]) == STATUS::EMPTY) {
			OnePlacement(x[index], y[index]);
			result = Judgement(x[index], y[index]);
			if (GAME_RESULT::NONE != result) return result;
		}
		else {
			result = GAME_RESULT::PLAYER1_WIN;
		}
	}
	
	TurnChange();
	return result;
}

void Connect6::OnePlacement(uint32_t iy, uint32_t ix) {
	TURN current_turn = GetCurrentTurn();
	m_board[iy][ix] = (STATUS)current_turn;
	m_turnCount++;
	return;
}

void Connect6::TurnChange(){
	m_currentTurn = (m_currentTurn == TURN::PLAYER1) ? TURN::PLAYER2 : TURN::PLAYER1;
	return;
}

GAME_RESULT Connect6::Judgement(uint32_t ix, uint32_t iy) {
	uint32_t temp_ix;
	uint32_t temp_iy;

	uint32_t dx[4] = { 1,1,0,-1 };
	uint32_t dy[4] = { 0,1,1,1 };
	uint32_t connect_count = 0;
	STATUS center = m_board[ix][iy];
	TURN current_turn = GetCurrentTurn();
	for (int x = 0; x < BOARD_SIZE; x++) {
		for (int y = 0; y < BOARD_SIZE; y++) {
			for (int i = 0; i < 4; i++) {
				if (x + dx[i] * 5 >= BOARD_SIZE || y + dy[i] * 5 >= BOARD_SIZE)continue;

				connect_count = 0;
				int tx = x, ty = y;

				for (int d = 0; d < 7; d++) {
					tx += dx[i];
					ty += dy[i];

					if (m_board[tx][ty] == center || m_board[tx][ty] == STATUS::BLOCKING)connect_count++;
					else { break; }
				}

				if (connect_count == 6) {
					switch (current_turn) {
					case TURN::PLAYER1: return GAME_RESULT::PLAYER1_WIN;
					case TURN::PLAYER2: return GAME_RESULT::PLAYER2_WIN;
					}
				}
				else if (connect_count > 6) {
					switch (current_turn) {
					case TURN::PLAYER1: return GAME_RESULT::PLAYER2_WIN;
					case TURN::PLAYER2: return GAME_RESULT::PLAYER1_WIN;
					}
				}
				connect_count = 0;
			}
		}
	}

	if (GetTurnCount() == 361) return GAME_RESULT::DRAW;
	return GAME_RESULT::NONE;
}

uint32_t Connect6::CheckIndex(uint32_t iy, uint32_t ix){
	return (iy >= 0 && ix >= 0 && iy < BOARD_SIZE && ix < BOARD_SIZE);
}

int Connect6::showboard(int x, int y)
{
	return (int)m_board[x][y];
}
