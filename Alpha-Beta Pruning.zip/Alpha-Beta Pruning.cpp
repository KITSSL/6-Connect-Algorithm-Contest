#include <climits>
#include <cstring>
#include <vector>

#define KIT_CUT_OFF(alpha, beta, depth) if ((depth) > 1 && (depth) % 2 == 1 && (alpha) >= (beta)) break;

enum KIT_PLAYER
{
    KIT_PLAYER1 = 1,
    KIT_PLAYER2 = 2
};

enum KIT_TURN
{
    KIT_PLAYER1_TURN1 = 1,
    KIT_PLAYER1_TURN2 = 2,
    KIT_PLAYER2_TURN1 = 4,
    KIT_PLAYER2_TURN2 = 8
};

enum KIT_RANGE
{
    KIT_RANGE_OUT = 0,
    KIT_RANGE_IN  = 1,
    KIT_BLOCKING  = 2
};

enum KIT_FLAG
{
    KIT_PLAYER1_FLAG = 1,
    KIT_PLAYER2_FLAG = 2
};

struct KITCoord
{
    int x;
    int y;
};

struct KITWeight
{
    int maxConnect;
    int connectNumber;
};

struct KITReturn
{
    std::vector<KITCoord> coord;
    KITWeight             weight;
};

static const int KIT_MAX_DEPTH   = 3;
static const int KIT_AXIS_LENGTH = 19;
static const int KIT_BOARD_SIZE  = KIT_AXIS_LENGTH * KIT_AXIS_LENGTH;
static const int KIT_MAX_COORD   = KIT_AXIS_LENGTH - 1;

KITReturn AlphaBetaPruning(int (*board)[KIT_AXIS_LENGTH], KIT_RANGE (*rangeBoard)[KIT_AXIS_LENGTH], std::vector<KITCoord> coord, int depth, int alpha1, int beta1, int alpha2, int beta2, KIT_TURN turn, KIT_FLAG flag)
{
    int       copyBoard[KIT_AXIS_LENGTH][KIT_AXIS_LENGTH];
    KIT_RANGE copyRangeBoard[KIT_AXIS_LENGTH][KIT_AXIS_LENGTH];
    KITReturn value, propValue;

    if (depth == KIT_MAX_DEPTH || (coord[coord.size() - 1].x == KIT_MAX_COORD && coord[coord.size() - 1].y == KIT_MAX_COORD))
        return { /* TODO: Return the heuristic value of coord */, coord };

    if (turn == KIT_PLAYER1_TURN1 || turn == KIT_PLAYER1_TURN2)
    {
        value.weight.maxConnect    = (flag == KIT_PLAYER1_FLAG) ? (INT_MIN) : (INT_MAX);
        value.weight.connectNumber = (flag == KIT_PLAYER1_FLAG) ? (INT_MIN) : (INT_MAX);

        for (int index = 0; index < KIT_BOARD_SIZE; ++index)
        {
            if (rangeBoard[index % KIT_AXIS_LENGTH][index / KIT_AXIS_LENGTH] != KIT_RANGE_IN)
                continue;

            memcpy(copyBoard, board, sizeof(int) * KIT_BOARD_SIZE);
            copyBoard[index % KIT_AXIS_LENGTH][index / KIT_AXIS_LENGTH] = KIT_PLAYER1;

            memcpy(copyRangeBoard, rangeBoard, sizeof(int) * KIT_BOARD_SIZE);
            // TODO: Get new range board

            coord.push_back({ index % KIT_AXIS_LENGTH, index / KIT_AXIS_LENGTH });
            propValue = AlphaBetaPruning(copyBoard, copyRangeBoard, coord, depth + 1, alpha1, beta1, alpha2, beta2, KIT_TURN((turn << 1) % 15), flag);

            if (flag == KIT_PLAYER1_FLAG)
            {
                value.weight.connectNumber = (value.weight.maxConnect == propValue.weight.maxConnect && value.weight.connectNumber > propValue.weight.connectNumber) ? (value.weight.connectNumber) : (propValue.weight.connectNumber);
                alpha2                     = (alpha2 > value.weight.connectNumber) ? (alpha2) : (value.weight.connectNumber);
                KIT_CUT_OFF(alpha2, beta2, depth);

                value.weight.maxConnect = (value.weight.maxConnect > propValue.weight.maxConnect) ? (value.weight.maxConnect) : (propValue.weight.maxConnect);
                alpha1                  = (alpha1 > value.weight.maxConnect) ? (alpha1) : (value.weight.maxConnect);
                KIT_CUT_OFF(alpha1, beta1, depth);
            }
            else
            {
                value.weight.connectNumber = (value.weight.maxConnect == propValue.weight.maxConnect && value.weight.connectNumber < propValue.weight.connectNumber) ? (value.weight.connectNumber) : (propValue.weight.connectNumber);
                beta2                      = (beta2 < value.weight.connectNumber) ? (beta2) : (value.weight.connectNumber);
                KIT_CUT_OFF(alpha2, beta2, depth);

                value.weight.maxConnect = (value.weight.maxConnect < propValue.weight.maxConnect) ? (value.weight.maxConnect) : (propValue.weight.maxConnect);
                beta1                   = (beta1 < value.weight.maxConnect) ? (beta1) : (value.weight.maxConnect);
                KIT_CUT_OFF(alpha1, beta1, depth);
            }
        }

        return value;
    }
    else
    {
        value.weight.maxConnect    = (flag == KIT_PLAYER2_FLAG) ? (INT_MIN) : (INT_MAX);
        value.weight.connectNumber = (flag == KIT_PLAYER2_FLAG) ? (INT_MIN) : (INT_MAX);

        for (int index = 0; index < KIT_BOARD_SIZE; ++index)
        {
            if (rangeBoard[index % KIT_AXIS_LENGTH][index / KIT_AXIS_LENGTH] != KIT_RANGE_IN)
                continue;

            memcpy(copyBoard, board, sizeof(int) * KIT_BOARD_SIZE);
            copyBoard[index % KIT_AXIS_LENGTH][index / KIT_AXIS_LENGTH] = KIT_PLAYER2;

            memcpy(copyRangeBoard, rangeBoard, sizeof(int) * KIT_BOARD_SIZE);
            // TODO: Get new range board

            coord.push_back({ index % KIT_AXIS_LENGTH, index / KIT_AXIS_LENGTH });
            propValue = AlphaBetaPruning(copyBoard, copyRangeBoard, coord, depth + 1, alpha1, beta1, alpha2, beta2, KIT_TURN((turn << 1) % 15), flag);

            if (flag == KIT_PLAYER2_FLAG)
            {
                value.weight.connectNumber = (value.weight.maxConnect == propValue.weight.maxConnect && value.weight.connectNumber > propValue.weight.connectNumber) ? (value.weight.connectNumber) : (propValue.weight.connectNumber);
                alpha2                     = (alpha2 > value.weight.connectNumber) ? (alpha2) : (value.weight.connectNumber);
                KIT_CUT_OFF(alpha2, beta2, depth);

                value.weight.maxConnect = (value.weight.maxConnect > propValue.weight.maxConnect) ? (value.weight.maxConnect) : (propValue.weight.maxConnect);
                alpha1                  = (alpha1 > value.weight.maxConnect) ? (alpha1) : (value.weight.maxConnect);
                KIT_CUT_OFF(alpha1, beta1, depth);
            }
            else
            {
                value.weight.connectNumber = (value.weight.maxConnect == propValue.weight.maxConnect && value.weight.connectNumber < propValue.weight.connectNumber) ? (value.weight.connectNumber) : (propValue.weight.connectNumber);
                beta2                      = (beta2 < value.weight.connectNumber) ? (beta2) : (value.weight.connectNumber);
                KIT_CUT_OFF(alpha2, beta2, depth);

                value.weight.maxConnect = (value.weight.maxConnect < propValue.weight.maxConnect) ? (value.weight.maxConnect) : (propValue.weight.maxConnect);
                beta1                   = (beta1 < value.weight.maxConnect) ? (beta1) : (value.weight.maxConnect);
                KIT_CUT_OFF(alpha1, beta1, depth);
            }
        }

        return value;
    }
}